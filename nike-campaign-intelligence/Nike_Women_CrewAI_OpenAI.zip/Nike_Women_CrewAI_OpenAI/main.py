import os
from datetime import datetime
from dotenv import load_dotenv

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from crewai import Agent, Task, Crew, Process, LLM


# =========================
# 1. LOAD OPENAI API KEY
# =========================

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY not found. Add it inside your .env file.")


llm = LLM(
    model="openai/gpt-4o-mini",
    api_key=OPENAI_API_KEY,
    temperature=0.25
)


# =========================
# 2. FOLDERS
# =========================

INPUT_DIR = "input_data"
OUTPUT_DIR = "outputs"
CHART_DIR = os.path.join(OUTPUT_DIR, "charts")

os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(CHART_DIR, exist_ok=True)


# =========================
# 3. READ INPUT FILES
# =========================

def read_file(file_name):
    path = os.path.join(INPUT_DIR, file_name)

    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing input file: {path}")

    with open(path, "r", encoding="utf-8") as file:
        return file.read()


market_research = read_file("market_research.txt")
women_customer_notes = read_file("women_customer_notes.txt")
competitor_data_input = read_file("competitor_data.txt")
nike_brand_data = read_file("nike_brand_data.txt")
campaign_requirements = read_file("campaign_requirements.txt")
qa_checklist = read_file("qa_checklist.txt")


# =========================
# 4. FIXED DATA FOR CHARTS
# =========================

segment_data = pd.DataFrame({
    "Segment": ["Women Running", "Women Training", "Women Athleisure", "Women Yoga", "Women Outdoor"],
    "Opportunity Score": [90, 84, 88, 78, 70]
})

competitor_score_data = pd.DataFrame({
    "Brand": ["Nike", "Adidas", "Puma", "New Balance", "Under Armour", "On"],
    "Women Market Relevance": [88, 85, 74, 76, 65, 80]
})

kpi_data = pd.DataFrame({
    "KPI": ["Reach", "Engagement", "Conversion", "Brand Awareness", "Community Growth"],
    "Expected Score": [86, 84, 70, 88, 82]
})

budget_data = pd.DataFrame({
    "Channel": ["Instagram", "TikTok", "YouTube Shorts", "Nike App", "Local Events"],
    "Budget Share": [30, 25, 15, 15, 15]
})


# =========================
# 5. CREATE CHARTS
# =========================

def create_bar_chart(data, x_col, y_col, title, filename):
    path = os.path.join(CHART_DIR, filename)
    plt.figure(figsize=(9, 5))
    plt.bar(data[x_col], data[y_col])
    plt.title(title)
    plt.xlabel(x_col)
    plt.ylabel(y_col)
    plt.xticks(rotation=20)
    plt.tight_layout()
    plt.savefig(path)
    plt.close()
    return path


market_chart = create_bar_chart(
    segment_data,
    "Segment",
    "Opportunity Score",
    "Women Sportswear Opportunity by Segment",
    "women_market_opportunity.png"
)

competitor_chart = create_bar_chart(
    competitor_score_data,
    "Brand",
    "Women Market Relevance",
    "Women Sportswear Competitor Relevance",
    "women_competitor_relevance.png"
)

kpi_chart = create_bar_chart(
    kpi_data,
    "KPI",
    "Expected Score",
    "Expected Campaign KPI Performance",
    "campaign_kpi_performance.png"
)

budget_chart = create_bar_chart(
    budget_data,
    "Channel",
    "Budget Share",
    "Recommended Budget Allocation",
    "budget_allocation.png"
)


# =========================
# 6. AGENTS
# =========================

market_agent = Agent(
    role="Women Sportswear Market Research Agent",
    goal="Analyze the German women's sportswear market for Nike with clear market opportunities and risks.",
    backstory="You are a senior market research analyst specializing in women's sportswear, activewear, running, training, athleisure, and the German retail market.",
    llm=llm,
    verbose=True
)

customer_agent = Agent(
    role="Women Consumer Segmentation Agent",
    goal="Identify and define the most attractive female customer segments for Nike in Germany.",
    backstory="You are a consumer insights specialist focused on female fitness consumers, lifestyle behavior, buying motivation, digital channels, and persona development.",
    llm=llm,
    verbose=True
)

competitor_agent = Agent(
    role="Competitor Benchmarking Agent",
    goal="Benchmark Nike against Adidas, Puma, New Balance, Under Armour, and On in women's sportswear in Germany.",
    backstory="You are a competitor intelligence analyst who compares brands using pricing, positioning, product portfolio, strengths, weaknesses, and strategic gaps.",
    llm=llm,
    verbose=True
)

strategy_agent = Agent(
    role="Strategic Positioning Agent",
    goal="Develop Nike's positioning strategy for women's sportswear in Germany based on market, customer, and competitor insights.",
    backstory="You are a brand strategist who builds clear value propositions, positioning statements, SWOT analysis, and strategic recommendations.",
    llm=llm,
    verbose=True
)

campaign_agent = Agent(
    role="Campaign and KPI Planning Agent",
    goal="Create a realistic Nike women's sportswear campaign plan with channels, timeline, KPIs, and budget allocation.",
    backstory="You are a digital campaign strategist who turns strategic positioning into practical campaign actions, content ideas, and measurable KPIs.",
    llm=llm,
    verbose=True
)

report_agent = Agent(
    role="Final Report and QA Agent",
    goal="Review all outputs, remove repetition, check quality, and produce the final professional market research and campaign strategy report.",
    backstory="You are a senior marketing consultant responsible for executive-level reports, structured recommendations, QA checks, and presentation-ready formatting.",
    llm=llm,
    verbose=True
)


# =========================
# 7. TASKS
# =========================

task1 = Task(
    description=f"""
You are preparing the first section of a professional market research report.

Scope:
- Brand: Nike
- Country: Germany
- Focus: Women's sportswear only
- Categories: running, training, athleisure, yoga, outdoor

Input data:
{market_research}

Nike context:
{nike_brand_data}

Chart data:
{segment_data.to_markdown(index=False)}

Required output:
1. Executive summary of the German women's sportswear market
2. 5 key market trends
3. PESTEL analysis in a compact table
4. Porter's Five Forces in a compact table
5. Market opportunity ranking by segment
6. 3 major opportunities for Nike
7. 3 major risks for Nike

Rules:
- Use concise bullet points.
- Use tables where possible.
- Do not write long paragraphs.
- Do not create customer personas.
- Do not create campaign ideas.
- Maximum 750 words.
""",
    expected_output="Professional market research section with PESTEL, Porter's Five Forces, opportunities, and risks.",
    agent=market_agent
)

task2 = Task(
    description=f"""
You are preparing the customer insight section of the report.

Scope:
- Brand: Nike
- Country: Germany
- Focus: Female sportswear consumers

Input data:
{women_customer_notes}

Use market findings from Agent 1, but do not repeat the full market analysis.

Required output:
1. Customer segmentation table with 4 female segments
2. Segment attractiveness score from 1 to 10
3. Recommended target segment and reason
4. 3 buyer personas:
   - Urban Runner
   - Gym and Training Enthusiast
   - Athleisure Lifestyle Consumer
5. Customer journey table:
   Awareness → Consideration → Purchase → Loyalty
6. Key buying motivations and pain points

Rules:
- Use tables and bullets.
- Avoid repeating PESTEL or Porter's analysis.
- Maximum 750 words.
""",
    expected_output="Customer segmentation, target segment recommendation, personas, and customer journey.",
    agent=customer_agent,
    context=[task1]
)

task3 = Task(
    description=f"""
You are preparing the competitor benchmarking section of the report.

Scope:
- Brand: Nike
- Country: Germany
- Focus: Women's sportswear

Input data:
{competitor_data_input}

Chart data:
{competitor_score_data.to_markdown(index=False)}

Compare:
- Nike
- Adidas
- Puma
- New Balance
- Under Armour
- On

Required output:
1. Competitor comparison table:
   Brand | Women's sportswear positioning | Strength | Weakness | Threat level
2. Pricing and product portfolio comparison
3. Strategic gap analysis
4. Nike's top 3 competitive advantages
5. Nike's top 3 competitive risks

Rules:
- Do not repeat customer personas.
- Do not create campaign ideas.
- Maximum 700 words.
""",
    expected_output="Competitor benchmark with pricing, positioning, strategic gaps, advantages, and risks.",
    agent=competitor_agent,
    context=[task1, task2]
)

task4 = Task(
    description=f"""
You are preparing the strategic analysis section of the report.

Use:
- Market research from Agent 1
- Customer segmentation from Agent 2
- Competitor benchmarking from Agent 3
- Nike brand data below:
{nike_brand_data}

Required output:
1. SWOT analysis in a 2x2 table
2. Value proposition for Nike women's sportswear in Germany
3. Positioning statement
4. Strategic recommendation:
   - target segment
   - core message
   - differentiation point
   - reason to believe
5. Strategic implication for campaign planning

Rules:
- Do not repeat full market, customer, or competitor sections.
- Focus on synthesis and decision-making.
- Maximum 650 words.
""",
    expected_output="SWOT, value proposition, positioning statement, and strategic recommendation.",
    agent=strategy_agent,
    context=[task1, task2, task3]
)

task5 = Task(
    description=f"""
You are preparing the campaign planning section of the report.

Scope:
- Brand: Nike
- Country: Germany
- Focus: Women's sportswear
- Target audience: Female runners, training users, and athleisure consumers

Campaign requirements:
{campaign_requirements}

KPI data:
{kpi_data.to_markdown(index=False)}

Budget data:
{budget_data.to_markdown(index=False)}

Use the positioning from Agent 4.

Required output:
1. Campaign name and campaign idea
2. Campaign objective
3. Core message
4. Channel strategy table
5. 4-week campaign calendar table
6. KPI framework table
7. Budget allocation summary
8. Success metrics

Rules:
- Be realistic and implementation-oriented.
- Do not repeat SWOT or competitor analysis.
- Maximum 800 words.
""",
    expected_output="Campaign plan with channels, 4-week calendar, KPIs, budget summary, and success metrics.",
    agent=campaign_agent,
    context=[task4]
)

task6 = Task(
    description=f"""
You are the final QA and report generation agent.

QA checklist:
{qa_checklist}

Use all previous outputs to create one final report.

Required report structure:
1. Title
2. Executive Summary
3. Market Research
4. Customer Segmentation
5. Competitor Benchmarking
6. Strategic Positioning
7. Campaign Plan
8. KPI and Budget Dashboard
9. Risks and Mitigation
10. Final Recommendation

QA rules:
- Remove repetition.
- Keep the focus strictly on women's sportswear in Germany.
- Make the report professional, clear, and presentation-ready.
- Use bullets and tables.
- Mention where charts should be inserted:
  [Insert Chart: women_market_opportunity.png]
  [Insert Chart: women_competitor_relevance.png]
  [Insert Chart: campaign_kpi_performance.png]
  [Insert Chart: budget_allocation.png]
- Maximum 1,200 words.
""",
    expected_output="Final professional Nike women's sportswear campaign intelligence report.",
    agent=report_agent,
    context=[task1, task2, task3, task4, task5]
)


# =========================
# 8. CREATE CREW
# =========================

crew = Crew(
    agents=[
        market_agent,
        customer_agent,
        competitor_agent,
        strategy_agent,
        campaign_agent,
        report_agent
    ],
    tasks=[
        task1,
        task2,
        task3,
        task4,
        task5,
        task6
    ],
    process=Process.sequential,
    verbose=True
)


# =========================
# 9. RUN CREW
# =========================

print("Starting Nike Women's Sportswear Campaign Intelligence System...")

try:
    result = crew.kickoff()
except Exception as error:
    print("\nERROR OCCURRED")
    print(error)
    print("\nCheck:")
    print("1. OPENAI_API_KEY is correct in .env")
    print("2. OpenAI billing is active")
    print("3. Internet is connected")
    print("4. Input files exist inside input_data folder")
    raise


# =========================
# 10. SAVE OUTPUT REPORT
# =========================

report_path = os.path.join(OUTPUT_DIR, "nike_women_sportswear_report.md")

with open(report_path, "w", encoding="utf-8") as file:
    file.write("# Nike Women's Sportswear Campaign Intelligence System\n\n")
    file.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n")

    file.write("## Agent Workflow\n\n")
    file.write(
        "Market Research → Women Consumer Segmentation → Competitor Benchmarking → "
        "Strategic Positioning → Campaign & KPI Planning → Final Report & QA\n\n"
    )

    file.write("## Generated Charts\n\n")
    file.write(f"- {market_chart}\n")
    file.write(f"- {competitor_chart}\n")
    file.write(f"- {kpi_chart}\n")
    file.write(f"- {budget_chart}\n\n")

    file.write("---\n\n")
    file.write(str(result))

print("\nDEMO COMPLETED SUCCESSFULLY")
print(f"Report saved here: {report_path}")
print(f"Charts saved here: {CHART_DIR}")